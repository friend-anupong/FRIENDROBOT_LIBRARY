/*
    ---------------"Friend Robot"---------------
    Library : ModelPro
    Website : https://www.friendrobot.co
    Page Facebook : Friend Robot
    Line@ : @friendrobot
    --------------------------------------------
*/

#ifndef _ModelPro_H_
#define _ModelPro_H_

#if defined(ARDUINO) || (ARDUINO >= 100)
#include "Arduino.h"
#else
#include "WProgram.h"
//#include <WApplet.c>
#endif
#include "Wire.h"
#include "ModelPro_motor.h"	
#include "ModelPro_oled.h"	
#include "ModelPro_analog.h"
#include "ModelPro_in_out.h"
#include "ModelPro_DHT.h"
#include "ModelPro_bluetooth.h"
#include "ModelPro_encoder.h"

#include <Servo.h>
#include <PS2X_lib.h>

Servo myservo1;
Servo myservo2;
Servo myservo3;
Servo myservo4;
Servo myservo5;
Servo myservo6;
Servo myservo7;
Servo myservo8;

void XIO(){
    myservo1.attach(32);
    myservo2.attach(33);
    myservo3.attach(34);
    myservo4.attach(35);
    myservo5.attach(36);
    myservo6.attach(37);
    myservo7.attach(38);
    myservo8.attach(39);
    oledOk();
    setTextSize(1); 
    oledClear();
}
void OK(){
    XIO();
    oledLogo();
    oled(30, 40, "Friend Robot");
    sound(2000,100);
    while (SW_OK() == 1) {
        oled(23, 50, "Press OK -> Run");
        oled(23, 50, "Press OK -> Run");
        oled(23, 50, "               ");
        oled(23, 50, "               ");
    } 
    beep();
}

void servo(int p,int s){
    if( p == 1){
        myservo1.write(s);
    }
    else if( p == 2){
        myservo2.write(s);
    }
    else if( p == 3){
        myservo3.write(s);
    }
    else if( p == 4){
        myservo4.write(s);
    }
    else if( p == 5){
        myservo5.write(s);
    }
    else if( p == 6){
        myservo6.write(s);
    }else if( p == 7){
        myservo7.write(s);
    }
    else {
        myservo8.write(s);
    }
}

#endif