/*
    ---------------"Friend Robot"---------------
    Library : ModelNano_analog
    Website : https://www.friendrobot.co
    Page Facebook : Friend Robot
    Line@ : @friendrobot
    --------------------------------------------
*/

#ifndef _ModelNano_analog_H_
#define _ModelNano_analog_H_

unsigned int analog(char ch)
{
  		analogRead(ch);
  		return(analogRead(ch));         
}
unsigned int knob()
{
    unsigned int  value = map(analogRead(A6),0,1023,0,1000);
    return(value);
}

unsigned int knob(unsigned int scale)
{
    unsigned int  value = map(analogRead(A6),0,1023,0,scale);
    return(value);
}

int knob(int scaleCCW, int scaleCW)
{
    unsigned int  value = map(analogRead(A6),0,1023,scaleCCW,scaleCW);
    return(value);
}
int getdist(int p) {
  double value = analog (p);
  if (value < 16) value = 16;
  return 2076.0 / (value - 11.00);
}

#endif