/*
    ---------------"Friend Robot"---------------
    Library : ModelPro_ModelNano_in_out
    Website : https://www.friendrobot.co
    Page Facebook : Friend Robot
    Line@ : @friendrobot
    --------------------------------------------
*/

#ifndef _ModelPro_ModelNano_in_out_H_
#define _ModelPro_ModelNano_in_out_H_

void out(char _pin,int _data){
    pinMode(_pin, OUTPUT); 
    digitalWrite(_pin,_data);
}
int in(char _pin){
    pinMode( _pin,INPUT_PULLUP);
    return(digitalRead( _pin));
}
int SW_OK(){
    pinMode( 4,INPUT);
    return(digitalRead(4));
}
void beep(){
    pinMode(8, OUTPUT); 
    tone(8, 1000);
    delay(80);
    noTone(8);
}
void sound(int s,int Time){
    pinMode(8, OUTPUT); 
    tone(8, s);
    delay(Time);
    noTone(8);
}
int ultrasonic(int trig, int echo) {
  long duration, cm;

  pinMode(trig, OUTPUT);

  digitalWrite(trig, LOW);
  delayMicroseconds(2);
  digitalWrite(trig, HIGH);
  delayMicroseconds(5);
  digitalWrite(trig, LOW);
  pinMode(echo, INPUT);
  duration = pulseIn(echo, HIGH);

  cm = duration / 29 / 2;
  delay(10);
  return cm;
}
#endif