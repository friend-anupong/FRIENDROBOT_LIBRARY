/*
    ---------------"Friend Robot"---------------
    Library : ModelPro_ModelPro_in_out
    Website : https://www.friendrobot.co
    Page Facebook : Friend Robot
    Line@ : @friendrobot
    --------------------------------------------
*/

#ifndef _ModelPro_ModelPro_in_out_H_
#define _ModelPro_ModelPro_in_out_H_

void out(char _pin,int _data)
{
    pinMode(_pin, OUTPUT); 
    digitalWrite(_pin,_data);
}
int in(char _pin)
{
    pinMode( _pin,INPUT); 
    return(digitalRead( _pin));
}
int SW_OK(){
    pinMode( 29,INPUT); 
    return(digitalRead(29));
}
void beep()
{
    pinMode(10, OUTPUT); 
    tone(10, 1000);
    delay(80);
    noTone(10);
}
void sound(int s,int Time)
{
    pinMode(10, OUTPUT); 
    tone(10, s);
    delay(Time);
    noTone(10);
}
int ultrasonic(int trig, int echo) {
  long duration, cm;

  pinMode(trig, OUTPUT);

  digitalWrite(trig, LOW);
  delayMicroseconds(2);
  digitalWrite(trig, HIGH);
  delayMicroseconds(5);
  digitalWrite(trig, LOW);
  pinMode(echo, INPUT);
  duration = pulseIn(echo, HIGH);

  cm = duration / 29 / 2;
  return cm;
}

#endif