/*
    ---------------"Friend Robot"---------------
    Library : ModelPro_motor
    Website : https://www.friendrobot.co
    Page Facebook : Friend Robot
    Line@ : @friendrobot
    --------------------------------------------
*/

#ifndef _ModelPro_motor_H_
#define _ModelPro_motor_H_

//Motor 1
#define Pwm1 11 //Speed control
#define InA1 15 //Direction
#define InB1 16 //Direction

//Motor 2
#define Pwm2 12 //Speed control
#define InA2 17 //Direction
#define InB2 22 //Direction

//Motor 3
#define Pwm3 13 //Speed control
#define InA3 23 //Direction
#define InB3 24 //Direction

//Motor 4
#define Pwm4 9 //Speed control
#define InA4 25 //Direction
#define InB4 26 //Direction

void motor(char ch, int Pow)
{
  long p = 0;
  if (Pow >= -100 && Pow <= 100)
  {
    
    p = map(Pow,0,100,0,255);
    if (ch == 1 && Pow > 0)
    {
      pinMode(InA1, OUTPUT);
      pinMode(InB1, OUTPUT);
      pinMode(Pwm1, OUTPUT);
      digitalWrite(InA1, LOW);
      digitalWrite(InB1, HIGH);
      analogWrite(Pwm1, (int)p);
    }
    else if (ch == 1 && Pow <= 0)
    {
      pinMode(InA1, OUTPUT);
      pinMode(InB1, OUTPUT);
      pinMode(Pwm1, OUTPUT);
      digitalWrite(InA1, HIGH);
      digitalWrite(InB1, LOW);
      analogWrite(Pwm1, -(int)p);
    }
    else if (ch == 2 && Pow > 0)
    {
      pinMode(InA2, OUTPUT);
      pinMode(InB2, OUTPUT);
      pinMode(Pwm2, OUTPUT);
      digitalWrite(InA2, LOW);
      digitalWrite(InB2, HIGH);
      analogWrite(Pwm2, (int)p);
    }
    else if (ch == 2 && Pow <= 0)
    {
      pinMode(InA2, OUTPUT);
      pinMode(InB2, OUTPUT);
      pinMode(Pwm2, OUTPUT);
      digitalWrite(InA2, HIGH);
      digitalWrite(InB2, LOW);
      analogWrite(Pwm2, -(int)p);
    }
    else if (ch == 3 && Pow > 0)
    {
      pinMode(InA3, OUTPUT);
      pinMode(InB3, OUTPUT);
      pinMode(Pwm3, OUTPUT);
      digitalWrite(InA3, LOW);
      digitalWrite(InB3, HIGH);
      analogWrite(Pwm3, (int)p);
    }
    else if (ch == 3 && Pow <= 0)
    {
      pinMode(InA3, OUTPUT);
      pinMode(InB3, OUTPUT);
      pinMode(Pwm3, OUTPUT);
      digitalWrite(InA3, HIGH);
      digitalWrite(InB3, LOW);
      analogWrite(Pwm3, -(int)p);
    }
    else if (ch == 4 && Pow > 0)
    {
      pinMode(InA4, OUTPUT);
      pinMode(InB4, OUTPUT);
      pinMode(Pwm4, OUTPUT);
      digitalWrite(InA4, HIGH);
      digitalWrite(InB4, LOW);
      analogWrite(Pwm4, (int)p);
    }
    else if (ch == 4 && Pow <= 0)
    {
      pinMode(InA4, OUTPUT);
      pinMode(InB4, OUTPUT);
      pinMode(Pwm4, OUTPUT);
      digitalWrite(InA4, LOW);
      digitalWrite(InB4, HIGH);
      analogWrite(Pwm4, -(int)p);
    }
  }
}

#endif