/*
    ---------------"Friend Robot"---------------
    Library : ModelPro_ModelNano_in_out
    Website : https://www.friendrobot.co
    Page Facebook : Friend Robot
    Line@ : @friendrobot
    --------------------------------------------
*/

#ifndef _ModelPro_ModelNano_DHT_H_
#define _ModelPro_ModelNano_DHT_H_
#include "DHT.h"

#define DHTPIN11 2
#define DHTTYPE11 DHT11

#define DHTPIN22 2
#define DHTTYPE22 DHT22

DHT dht11(DHTPIN11, DHTTYPE11);
DHT dht22(DHTPIN22, DHTTYPE22);

int dht11Humidity(){
    dht11.begin();
    int h = dht11.readHumidity();
    while( h <= 0){
        h = dht11.readHumidity();
    }
    return h;
}

int dht11TemperatureC(){
    dht11.begin();
    int t = dht11.readTemperature();
    while( t <= 0){
        t = dht11.readTemperature();
    }
    return t;
}

int dht11TemperatureF(){
    dht11.begin();
    int f = dht11.readTemperature(true);
    while( f <= 0){
        f = dht11.readTemperature(true);
    }
    return f;
}

int dht22Humidity(){
    dht22.begin();
    int h = dht22.readHumidity();
    while( h <= 0){
        h = dht22.readHumidity();
    }
    return h;
}

int dht22TemperatureC(){
    dht22.begin();
    int t = dht22.readTemperature();
    while( t <= 0){
        t = dht22.readTemperature();
    }
    return t;
}

int dht22TemperatureF(){
    dht22.begin();
    int f = dht22.readTemperature(true);
    while( f <= 0){
        f = dht22.readTemperature(true);
    }
    return f;
}
#endif