/*
    ---------------"Friend Robot"---------------
    Library : ModelNano_motor
    Website : https://www.friendrobot.co
    Page Facebook : Friend Robot
    Line@ : @friendrobot
    --------------------------------------------
*/

#ifndef _ModelNano_motor_H_
#define _ModelNano_motor_H_


//Motor 1
#define Pwm1 5 //Speed control
#define InA1 12 //Direction
#define InB1 4 //Direction

//Motor 2
#define Pwm2 6 //Speed control
#define InA2 13 //Direction
#define InB2 7 //Direction


void motor(char ch, int Pow)
{
  long p = 0;
  if (Pow >= -100 && Pow <= 100)
  {
    
    p = map(Pow,0,100,0,255);
    if (ch == 1 && Pow > 0)
    {
      pinMode(InA1, OUTPUT);
      pinMode(InB1, OUTPUT);
      pinMode(Pwm1, OUTPUT);
      digitalWrite(InA1, LOW);
      digitalWrite(InB1, HIGH);
      analogWrite(Pwm1, (int)p);
    }
    else if (ch == 1 && Pow <= 0)
    {
      pinMode(InA1, OUTPUT);
      pinMode(InB1, OUTPUT);
      pinMode(Pwm1, OUTPUT);
      digitalWrite(InA1, HIGH);
      digitalWrite(InB1, LOW);
      analogWrite(Pwm1, -(int)p);
    }
    else if (ch == 2 && Pow > 0)
    {
      pinMode(InA2, OUTPUT);
      pinMode(InB2, OUTPUT);
      pinMode(Pwm2, OUTPUT);
      digitalWrite(InA2, LOW);
      digitalWrite(InB2, HIGH);
      analogWrite(Pwm2, (int)p);
    }
    else if (ch == 2 && Pow <= 0)
    {
      pinMode(InA2, OUTPUT);
      pinMode(InB2, OUTPUT);
      pinMode(Pwm2, OUTPUT);
      digitalWrite(InA2, HIGH);
      digitalWrite(InB2, LOW);
      analogWrite(Pwm2, -(int)p);
    }
  }
}

#endif