/*
    ---------------"Friend Robot"---------------
    Library : ModelPro_ModelNano_in_out
    Website : https://www.friendrobot.co
    Page Facebook : Friend Robot
    Line@ : @friendrobot
    --------------------------------------------
*/

#ifndef _ModelPro_ModelNano_bluetooth_H_
#define _ModelPro_ModelNano_bluetooth_H_

#include <SoftwareSerial.h>

SoftwareSerial mySerial(2, 3); //Tx,Rx
    int b = NULL;

int bluetooth(){
    mySerial.begin(9600);
    if (mySerial.available()) {
        b = mySerial.read();
    }
    return b;
}

#endif