/*
    ---------------"Friend Robot"---------------
    Library : ModelPro
    Website : https://www.friendrobot.co
    Page Facebook : Friend Robot
    Line@ : @friendrobot
    --------------------------------------------
*/

#ifndef _ModelNano_H_
#define _ModelNano_H_

#if defined(ARDUINO) || (ARDUINO >= 100)
#include "Arduino.h"
#else
#include "WProgram.h"
//#include <WApplet.c>
#endif
#include "Wire.h"
#include "ModelNano_motor.h"	
#include "ModelNano_oled.h"	
#include "ModelNano_analog.h"
#include "ModelNano_in_out.h"
#include "ModelNano_DHT.h"
#include "ModelNano_bluetooth.h"
#include "ModelNano_encoder.h"

#include <Servo.h>
#include <PS2X_lib.h>

Servo myservo1;
Servo myservo2;
Servo myservo3;

void XIO(){
    myservo1.attach(9);
    myservo2.attach(10);
    myservo3.attach(11);
    oledOk();
    setTextSize(1);
    oledClear();
}
void OK(){
    XIO();
    oledLogo();
    oled(30, 40, "Friend Robot");
    sound(2000,100);
    while (SW_OK() == 1) {
        oled(23, 50, "Press OK -> Run");
        oled(23, 50, "Press OK -> Run");
        oled(23, 50, "               ");
        oled(23, 50, "               ");
    } 
    beep();
}
void servo(int p,int s){
    if( p == 1){
        myservo1.write(s);
    }
    else if( p == 2){
        myservo2.write(s);
    }
    else {
        myservo3.write(s);
    }
}
#endif