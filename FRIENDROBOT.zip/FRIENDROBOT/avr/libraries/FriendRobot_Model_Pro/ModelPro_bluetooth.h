/*
    ---------------"Friend Robot"---------------
    Library : ModelPro_ModelNano_in_out
    Website : https://www.friendrobot.co
    Page Facebook : Friend Robot
    Line@ : @friendrobot
    --------------------------------------------
*/

#ifndef _ModelPro_ModelPro_bluetooth_H_
#define _ModelPro_ModelPro_bluetooth_H_

#include <SoftwareSerial.h>

int b = NULL;

int bluetooth(){
    Serial1.begin(9600);
    if (Serial1.available()) {
        b = Serial1.read();
    }
    return b;
}

#endif